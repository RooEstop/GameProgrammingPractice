#include <Windows.h>

HWND hWnd = NULL;
HRESULT initWin(HINSTANCE instanceHandle, int show);
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);


//Entry Point.
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR pCmdLine, int nCmdShow)
{
	if (FAILED(initWin(hInstance, nCmdShow)))
	{
		MessageBox(0, L"initWin - Failed", L"Error", MB_OK);
		return FALSE;
	}

	//Accept all input action from user. GetMessage return 0 when window is closed.
	MSG msg = {};
	while (GetMessage(&msg, NULL, 0, 0) != 0)
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (int)msg.wParam;
}

HRESULT initWin(HINSTANCE hInstance, int nCmdShow)
{
	//WIndows Class Init
	WNDCLASS wc = {};
	wc.lpfnWndProc = WndProc;	//Window Procedure
	wc.hInstance = hInstance;
	wc.lpszClassName = L"Hello";

	//RegisterClass() : Register WNDClass as class
	if (!RegisterClass(&wc)) {
		MessageBox(0, L"RegisterClass - Failed", 0, 0);
		return E_FAIL;
	}

	//CreateWindow : Create Window. Return initialize value to hWnd.
	hWnd = CreateWindow(L"Hello", L"Hello", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, NULL, NULL, hInstance, NULL);

	if (!hWnd) {
		MessageBox(0, L"CreateWindow - Failed", 0, 0);
		return E_FAIL;
	}

	//Show window on screen.
	ShowWindow(hWnd, nCmdShow);

	//Update window state.
	UpdateWindow(hWnd);

	return S_OK;
}

//Window Procedure Implement. Parameter is Fixed.
//Processing message (Event Handler)
LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_KEYDOWN:
		if (wParam == VK_ESCAPE)
			DestroyWindow(hWnd);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return 0;
}
