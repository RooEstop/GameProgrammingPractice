﻿#include <iostream>
#include <stack>

using namespace std;

struct MyStruct
{
	int key;
	char value;
};

int main()
{
	stack<MyStruct> s;
	
	MyStruct ts;

	for (int i{ 0 }; i < 5; i++) {
		ts.key = i+1;
		ts.value = 'A' + i;

		s.push(ts);
	}

	while (!s.empty())
	{
		cout << "Key : " << s.top().key << " Value : " << s.top().value << endl;
		s.pop();
	}
}