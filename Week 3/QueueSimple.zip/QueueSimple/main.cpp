﻿#include <iostream>
#include <queue>

using namespace std;

struct MyStruct
{
	int key;
	char value;
};

int main()
{
	queue<MyStruct> q;
	
	MyStruct ts;

	for (int i{ 0 }; i < 5; i++) {
		ts.key = i+1;
		ts.value = 'A' + i;

		q.push(ts);
	}

	while (!q.empty())
	{
		cout << "Key : " << q.front().key << " Value : " << q.front().value << endl;
		q.pop();
	}
}