﻿#include <iostream>
#include <print>
#include <list> //list
using namespace std;

void print_list(list<int> r, const char* head)
{
	cout << head;
	for (list<int>::iterator iter{ r.begin() }; iter != r.end(); iter++)
		cout << " " << *iter;
	cout << endl;
}

int main()
{
	list<int> l{ 3, 8 ,9 };
	list<int>::iterator iter = l.begin();
	print_list(l,"list : ");

	iter++;
	l.insert(iter,6);
	print_list(l, "list : ");

	l.insert(iter, 2, 7);
	print_list(l, "list : ");
	
	list<int> l2{ 4, 5 ,1 };
	iter = l.begin();
	iter++;
	l.insert(iter,l2.begin(), --l2.end());
	print_list(l, "list : ");
}
