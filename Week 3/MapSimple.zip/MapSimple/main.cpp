﻿#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

struct MyStringCompare {
	bool operator()(const char* s1, const char* s2) const {
		return strcmp(s1, s2) < 0;  //s1 < s2 일때 -1이고 true를 리턴하므로 오름차순임.
	}
};


int main()
{
	map<const char*, int, MyStringCompare> m;
	m["March"] = 31;
	m["April"] = 28;
	m["June"] = 30;

	cout << "April : " << m["April"] << endl;
	cout << "May : " << m["May"] << endl;

	m["April"] = 30;

	map<const char*, int>::iterator iter{ m.find("April") };
	cout << iter->first << " : " << iter->second << endl;

	for (map<const char*, int, MyStringCompare>::iterator iter{ m.begin() }; iter != m.end(); iter++)
		cout << iter->first << ' ' << iter->second << endl;
	cout << endl;


}