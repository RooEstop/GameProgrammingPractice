﻿#include <iostream>
#include <print>
#include <list> //list
using namespace std;

void print_list(list<int> r, const char* head)
{
	cout << head;
	for (list<int>::iterator iter{ r.begin() }; iter != r.end(); iter++)
		cout << " " << *iter;
	cout << ")" << endl;
}

int main()
{
	list<int> lst;
	lst.push_back(2); lst.push_back(5); lst.push_back(9);

	list<int>::iterator iter{ lst.begin() };
	print("First element : {}  ", *iter);	print_list(lst, "(list : ");
	*iter = 3;

	iter = lst.end();
	iter--;
	print("Last element : {}  ", *iter);	print_list(lst, "(list : ");
	iter--;
	*iter = 6;
	
	lst.push_front(1);
	iter = lst.begin();
	print("First element : {}  ", *iter);	print_list(lst, "(list : ");
	lst.pop_front();
	iter = lst.begin();
	print("First element : {}  ", *iter);	print_list(lst, "(list : ");
	 
	lst.push_back(10);
	lst.pop_back();
	iter = lst.end();
	iter--;
	print("Last element : {}  ", *iter);	print_list(lst, "(list : ");
}
