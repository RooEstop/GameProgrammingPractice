﻿#include <iostream>
#include <vector>
#include <print>
using namespace std;

void print_vector(vector<int> v, const char* head)
{
	cout << '\t' << head;
	for (vector<int>::iterator iter{ v.begin() }; iter != v.end(); iter++)
		cout << " " << *iter;
	cout << endl;
}

int main()
{
	vector<int> v1 {};
	v1.push_back(1); v1.push_back(2);
	println("Vector Size : {}", v1.size());

	v1.push_back(3); v1.push_back(4);
	println("Vector First Element : {}", v1.front());
}
