﻿#include <iostream>
#include <set>
#include <algorithm> //set_union,set_intersection

using namespace std;

void print_set(set<int> v, const char* head)
{
	cout << head;
	for (set<int>::iterator iter{ v.begin() }; iter != v.end(); iter++)
		cout << *iter << " ";
	cout << endl;
}

int main()
{
	set<int> s1;
	int A[8]{ 4, 2, 1, 2, 1, 2, 4, 1 };
	for (int i{ 0 }; i < 8; i++)
		s1.insert(A[i]);
	print_set(s1, "s1 = ");  //s1 = 1, 2, 4

	set<int> s2{ 5, 2, 3, 3, 1 };
	print_set(s2, "s2 = ");  //s2 = 1, 2, 3, 5

	set<int> s3;
	set_union(s1.begin(), s1.end(), s2.begin(), s2.end(), inserter(s3, s3.begin()));
	print_set(s3, "s3 = "); //합집합 s3 = 1, 2, 3, 4, 5


	set<int> s4;
	set_intersection(s1.begin(), s1.end(), s2.begin(), s2.end(), inserter(s4, s4.begin()));
	print_set(s4, "s4 = "); //교집합 s4 = 1, 2

	set<int> s5;
	set_difference(s1.begin(), s1.end(), s2.begin(), s2.end(), inserter(s5, s5.begin()));
	print_set(s5, "s5 = ");
}
