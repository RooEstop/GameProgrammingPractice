﻿#include <iostream>

class MyClass
{
};

class MyChildClass : public MyClass
{
};

void func(MyChildClass* mcc)
{
};

class MyClass2
{
	virtual int foo() = 0; // "=0;" 가 있으면 선언만 있고 정의가 없는 순수 가상 함수임. 반드시 순수 가상 함수일 필요는 없음.
	//virtual int foo() { return 1; }  //순수 가상 함수가 아니어도 됨.
};

class MyChildClass2 : public MyClass2
{
	virtual int foo() { return 7; } //virtual 키워드를 생략해도 됨
	//MyClass2의 foo가 순수 가상 함수라면 foo를 반드시 정의해야 하고, 그 외에는 자식 클래스에서 함수를 다르게 할 경우만 구현해주면 됨.
};

void func2(MyChildClass2* mcc)
{
};

int main()
{
	{
		// static_cast : C 언어의 타입 캐스팅과 동일한 의미의 타입 캐스팅 능력을 가짐
		int i{ 5 };
		//double d{ (double)i / 10 };
		double d{ static_cast<double>(i) / 10 }; //위와 동일한 기능
	}

	{
		// static_cast : 상속 계층 구조 상에서 아래 방향으로 되돌리기 위한 용도. 부모 클래스에 가상 함수가 없는 클래스의 경우에서 사용됨. 가상 함수가 있는 클래스이면 dynamic_cast를 사용해야 함.

		MyChildClass* mcc{ new MyChildClass{} };
		MyClass* mc{ mcc }; //묵시적 타입 변환

		MyChildClass* mcc2{ static_cast<MyChildClass*>(mc) };
	}

	{
		// const_cast : 표현식의 상수성(const)이나 휘발성(volatile)을 없애는 용도

		MyChildClass mcc;
		const MyChildClass& cmcc{ mcc };

		//func(&cmcc); //error: func은 비상수성 인수를 받는 함수임

		func(const_cast<MyChildClass*>(&cmcc)); //ok
		//func((MyChildClas*) &cmcc); 의 C 스타일도 가능하지만 피하자
	}

	{
		// dynamic_cast : 부모 클래스(가상 함수가 포함된 클래스) 객체의 포인터나 참조 타입을 자식 클래스 타입으로 안전하게 타입 캐스팅함
		MyClass2* mc{ new MyChildClass2{} };
		func2(dynamic_cast<MyChildClass2*>(mc)); //ok
	}

	{
		// reinterpret_cast : 상속관계과 무관하게 임의의 포인터 타입끼리 변환하도록 지원함
		int* pi{ reinterpret_cast<int*>(1234) };
		char* pc{ reinterpret_cast<char*>(pi) };
	}

	{
		float* pi{ reinterpret_cast<float*>(314) };
		int* ipi{ reinterpret_cast<int*>(pi) };
	}
}
