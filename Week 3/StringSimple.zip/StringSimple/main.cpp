﻿#include <iostream>
#include <string>

using namespace std;

int main()
{
	string s{ "one cat two cat three cat and more." };
	string cat{ "cat" };
	int count{ 0 };

	for (auto i{ 0 }; i < s.length(); i++)
	{
		auto j = s.find(cat,i);
		if (j != string::npos)
		{
			i = j + cat.length();
			count++;
		}
	}
	cout << "count : " << count <<  endl;
}