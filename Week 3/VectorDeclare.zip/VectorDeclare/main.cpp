﻿#include <iostream>
#include <vector>
using namespace std;

void print_vector(vector<int> v, const char* head)
{
	cout << '\t' << head;
	for (vector<int>::iterator iter{ v.begin() }; iter != v.end(); iter++)
		cout << " " << *iter;
	cout << endl;
}

int main()
{
	vector<int> v1; //빈 벡터를 생성함.
	print_vector(v1, "v1 = ");  //()

	vector<int> v2(3); //값이 모두 0인 3개의 원소를 가진 벡터를 생성함.
	print_vector(v2, "v2 = ");  //(0, 0, 0)

	vector<int> v3(5, 7); //값이 모두 2인 5개의 원소를 가진 벡터를 생성함.
	print_vector(v3, "v3 = ");  //(2, 2, 2, 2, 2)

	vector<int> v4(v3); //v3을 복사하여 새 벡터를 생성함.
	print_vector(v4, "v4 = ");  //(2, 2, 2, 2, 2)

	vector<int> v5(v4.begin() + 1, v4.begin() + 3); //v4의 [First, Last) 범위를 복사하여 새 벡터를 생성함.
	print_vector(v5, "v5 = ");  //(2, 2)

	vector<int> v6{ 7, 7, 7 }; //벡터를 생성하고 {2, 3, 4}의 값을 가지도록 초기화함.
	print_vector(v6, "v6 = ");  //(2, 3, 4)
}
