﻿#include <iostream>
#include <deque>
#include <print>
using namespace std;

struct MyStruct {
	int myInt;
};

void print_deque(deque<MyStruct> dq, const char* head)
{
	cout << head;
	MyStruct m;
	for (unsigned i{ 0 }; i < dq.size(); i++)
	{
		m = dq[i];
		cout << m.myInt << " ";
	}
	cout << endl;
}

int main()
{
	deque<MyStruct> dq;

	MyStruct m1{ 4 };
	MyStruct m2{ 3 };
	MyStruct m3{ 5 };

	dq.push_front(m3);
	dq.push_front(m2);
	dq.push_front(m1);

	print_deque(dq, "dq = ");
}
