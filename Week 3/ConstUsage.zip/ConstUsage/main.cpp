﻿#include <iostream>

void myfunc(const int c)
{
	//c = 2; //error
	int d{ c };
}

class MyClass
{
private:
	int c;
public:
	void myfunc() const
	{
		//c = 2; //error
		int d{ c };
	}
};

void myfunc_1(int a)
{
	int d{ a };
}

void myfunc_2(const int& a)
{
	int d{ a };
}

int main()
{
	{ 
		//const int c; //error
		const int c{ 5 };
		//c = 2; //error
		//c++; //error
	}

	{ 
		int c{ 5 };
		const int* p;
		//*p = 5; //error
		p = &c; //ok
	}

	{ 
		int c{ 5 };
		int* const p{ &c };
		*p = 5; //ok
		//p = &c; //error

	}

	{ 
		int c{ 5 };
		const int* const p{ &c };
		//*p = 5; //error
		//p = &c; //error
	}

	{ 
		myfunc(3);
		MyClass m;
		m.myfunc();
		myfunc_1(3);
		myfunc_2(3);
	}
}
