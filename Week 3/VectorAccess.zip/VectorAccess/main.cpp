﻿#include <iostream>
#include <vector>
#include <print>
using namespace std;

void print_vector(vector<int> v, const char* head)
{
	cout << '\t' << head;
	for (vector<int>::iterator iter{ v.begin() }; iter != v.end(); iter++)
		cout << " " << *iter;
	cout << endl;
}

int main()
{
	vector<int> v1 {};
	v1.push_back(1); v1.push_back(2); v1.push_back(3);
	println("Vector element2 : {}", v1[1]);
	println("Vector element23 : {}", v1.at(2));

	vector<int>::pointer ptr = { &v1[0] };
	println("Vector front ptr : {}", *ptr);
	ptr++;
	println("Vector second ptr : {}", *ptr);
	*ptr = 4;
	println("Vector second ptr : {}", *ptr);
}
