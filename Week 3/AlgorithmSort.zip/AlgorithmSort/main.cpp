﻿#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void print_vector(vector<int> v, const char* head)
{
	cout << head;
	for (vector<int>::iterator iter{ v.begin() }; iter != v.end(); iter++)
		cout << " " << *iter;
	cout << endl;
}

bool comp1(int x, int y) { return (x > y); }	//greater
bool comp2(int x, int y) { return (x < y); }	//less

int main()
{
	vector<int> v;
	for (int i = 0; i < 10; i++)
		v.push_back(rand() % 100);

	sort(v.begin(), v.end());
	print_vector(v, "v = ");
	
	sort(v.begin(), v.end(), greater<int>());
	print_vector(v, "v = ");

	sort(v.begin(), v.end(), comp2);
	print_vector(v, "v = ");

	sort(v.begin(), v.end(), comp1);
	print_vector(v, "v = ");
}