﻿#include <iostream>
#include "StackFloat.h"
using namespace std;

int main()
{
	StackFloat stack;
	float i{ 1 };

	cout << "스택에 원소들을 넣습니다:\n";
	while (stack.push(i)) { cout << i << ' '; i += 1; } //1 2 3 4 5 6 7 8 9 10
	cout << endl;

	cout << "스택에서 원소들을 뺍니다:\n";
	while (stack.pop(i)) { cout << i << ' '; } //10 9 8 7 6 5 4 3 2 1
	cout << endl;
}
