#pragma once

class StackFloat
{
private:
	int size;  // capacity
	int top;
	int* stackPtr;

public:
	StackFloat(float s = 10.0);
	~StackFloat() { delete[] stackPtr; }
	bool push(const float& item);
	bool pop(float& item);
	bool isEmpty() const { return (top == -1); }
	bool isFull() const { return (top == size - 1); }
};
