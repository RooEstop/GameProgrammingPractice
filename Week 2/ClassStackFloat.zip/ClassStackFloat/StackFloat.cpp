#include "StackFloat.h"

StackFloat::StackFloat(float s)
{
	size = s > 0 && s < 1000 ? s : 10; // default capacity 10
	stackPtr = new int[size];
	top = -1;  // initialize stack
}

bool StackFloat::push(const float& item)
{
	if (isFull()) return false;
	stackPtr[++top] = item;
	return true;
}

bool StackFloat::pop(float& item)
{
	if (isEmpty()) return false;
	item = stackPtr[top--];
	return true;
}
