﻿#include <iostream>
#include <cassert>

#define Assert(a,b) assert(a && b);

int divide(int a, int b)
{
    Assert(b != 0, "분모가 0입니다.");
    return a / b;
}

int main()
{
    int c = divide(5, 1);
}
