template <typename T>
class Stack
{
private:
    int size;
    int top;
    T* stackPtr;

public:
    Stack(int size = 5);
    ~Stack() { delete[] stackPtr; }
    bool push(const T& item);
    bool pop(T& item);
    bool isEmpty() const { return (top == -1); }
    bool isFull() const { return (top == size - 1); }
};

template <typename T>
Stack<T>::Stack(int s)
{
	size = s > 0 && s < 1000 ? s : 10;
	stackPtr = new T[size];
	top = -1;
}

template <typename T>
bool Stack<T>::push(const T& item)
{
	if (isFull()) return false;
	stackPtr[++top] = item;
	return true;
}

template <typename T>
bool Stack<T>::pop(T& item)
{
	if (isEmpty()) return false;
	item = stackPtr[top--];
	return true;
}

typedef Stack<int> ISTACK;
typedef Stack<float> FSTACK;
