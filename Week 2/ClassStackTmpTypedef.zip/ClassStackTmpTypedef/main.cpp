﻿#include <iostream>
#include "Stack.h"
using namespace std;

int main()
{
	ISTACK istack;
	int i{ 1 };
	cout << "스택에 원소들을 넣습니다:" << endl;
	while (istack.push(i)) { cout << i << ' '; i += 1; }
	cout << endl;

	cout << "스택에서 원소들을 뺍니다:" << endl;
	while (istack.pop(i)) { cout << i << ' '; }
	cout << endl;


	FSTACK fstack;
	float f{ 1 };
	cout << "스택에 원소들을 넣습니다:" << endl;
	while (fstack.push(f)) { cout << f << ' '; f += 1; }
	cout << endl;

	cout << "스택에서 원소들을 뺍니다:" << endl;
	while (fstack.pop(f)) { cout << f << ' '; }
	cout << endl;
}

