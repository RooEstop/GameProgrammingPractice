﻿#include <math.h>
import std;

int main()
{
    const float PI = 3.141592;
    std::println("sin(45) : {}", sin(PI / 4));
}