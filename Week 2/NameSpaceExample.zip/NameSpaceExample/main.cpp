﻿#include <iostream>
using namespace std;


int i{ 1 };

namespace first
{
	int i{ 2 };

	void print()
	{
		cout << "first::print(): " << i << endl;
	}

	namespace second
	{
		int j{ i + 2 };

		class myclass
		{
		public:
			int i{ j + first::i + ::i };
			void print()
			{
				cout << "first::second::myclass::print(): " << i << endl;
			}
		};
	}
}

int main()
{
	first::print();

	first::second::myclass obj;
	obj.print();

	cout << "main(): " << i + first::i + obj.i << endl;
}
