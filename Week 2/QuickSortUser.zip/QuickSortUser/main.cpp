﻿#include <iostream>
#include <math.h>

void print_array(const char* str, const int* list, int n)
{
    printf("%s = (", str);
    for (int i = 0; i < n; i++)
    {
        printf(" %6d%s", list[i], (i < n - 1) ? "," : ")\n");
    }
}

void qksort(int* list, int start, int end)
{
    if (start >= end) return;

    int pIndex = (end + start) / 2;
    int pivot = list[pIndex];
    
    int i = start, j = end;

    while (i <= j) {
        while (list[i] > pivot) i++;
        while (list[j] < pivot) j--;
        if (i <= j) {
            int temp = list[i];
            list[i] = list[j];
            list[j] = temp;
            i++; j--;
        }
    }
    qksort(list, start, j);
    qksort(list, i, end);
}

int main()
{
    srand((unsigned)time(NULL));


    int n = 10;
    int* list = (int*)malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++)
    {
        list[i] = rand();
    }

    print_array("정렬 전 : ", list, n);

    qksort(list, 0, n - 1);

    print_array("정렬 후 : ", list, n);
}