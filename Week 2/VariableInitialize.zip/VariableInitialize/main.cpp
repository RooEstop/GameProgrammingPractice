﻿#include <iostream>
#include <vector>
using namespace std;


int main()
{
	// 일반 변수의 초기화

	int n1 = 1;
	int n2{ 1 };
	int n3 = { 1 };
	int n4{}; //n4 = 0


	// 형변환 여부

	//int n5 = 1.1; //warning
	//int n6{ 1.1 }; //error
	//int n7 = { 1.1 }; //error

	// 배열의 초기화

	int a1[3]{ 1, 2, 3 };
	int a2[3] = { 1, 2, 3 };


	// 동적 메모리 변수의 초기화

	int* b1 = new int{}; //b1[0]=0;
	int* b2 = new int; //b2[0]=garbage;
	int* b3 = new int(); //b3[0]=0;
	int* b4 = new int(3); //b4[0]=3;
	int* b5 = new int{}; //b5[0]=0;
	int* b6 = new int{ 3 }; //b6[0]=0;

	int* b7 = new int[3]; //b7[0]=garbage,b7[1]=garbage,b7[3]=garbage
	int* b8 = new int[3] {}; //b8[0]=0,b8[1]=0,b8[3]=0
	int* b9 = new int[3] { 1, 2, 3 }; //b9[0]=1,b9[1]=2,b9[3]=3
	vector<int> v1{ 1, 2, 3 };
	vector<int> v2 = { 1, 2, 3 };

	vector<int> v3(4, 3);  // {3,3,3,3}. 4개를 3으로 초기화. //v3.size()=10
	vector<int> v4{ 4, 3 }; // {4,3}. //v4.size()=2

	// 구조체의 초기화

	struct Point
	{
		int x, y;
	};

	Point p1; //디폴트 생성자 Point()가 없다면 초기화되지 않음
	p1.x = 1;
	p1.y = 2;
	Point p2{ 1, 2 };
	Point p3 = { 1, 2 };

	// 클래스의 초기화

	class Complex
	{
	public:
		int re, im;
	public:
		Complex(int r, int i) : re(r), im(i) {}
	};

	Complex c1{ 1, 2 }; //c1.re=1, c1.im=2
	Complex c2 = { 1, 2 }; //c2.re=1, c2.im=2
	Complex c3(1, 2); //c2.re=1, c2.im=2; 생성자에 의해서 초기화됨

	// 클래스 내부 멤버 배열의 초기화

	class MyClass
	{
		int d1[3]{ 1, 2, 3 };
	};

	Point p4{ 1 };
	Point p5;

	printf("x : %d, y : %d", p4.x, p4.y);
	printf("x : %d, y : %d", p5.x, p5.y);
}