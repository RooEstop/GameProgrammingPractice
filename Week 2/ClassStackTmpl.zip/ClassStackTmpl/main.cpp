﻿#include <iostream>
#include "Stack.h"
using namespace std;

int main()
{
	Stack<float> istack;
	float i{ 1 };
	cout << "스택에 원소들을 넣습니다:" << endl;
	while (istack.push(i)) { cout << i << ' '; i += 1; }
	cout << endl;

	cout << "스택에서 원소들을 뺍니다:" << endl;
	while (istack.pop(i)) { cout << i << ' '; }
	cout << endl;
}

