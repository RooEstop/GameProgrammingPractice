﻿#include <iostream>
using namespace std;

template <typename T>
T maximum(T a, T b) {
	return a > b ? a : b;
}

template <typename T>
T mininum(T a, T b) {
	return a < b ? a : b;
}


int main()
{
	cout << "mininum(5, 3) = " << mininum(5, 3) << endl; //3
	cout << "mininum('x', 'y') = " << mininum('x', 'y') << endl;  //x
	cout << "mininum(3.3, 5.5) = " << mininum(3.3, 5.5) << endl;  //3.3
}
