#include <Windows.h>
#include <d2d1.h>
#pragma comment(lib, "d2d1")
#pragma comment(lib, "dwrite")
#pragma comment(lib, "WindowsCodecs")

#define SAFE_RELEASE(p) {if(p) { (p)->Release(); (p) = NULL;} }

class MyApp
{
public:
	MyApp() {};
	~MyApp() { DiscardDeviceResource(); DiscardAppResource(); };
	bool Initialize(HINSTANCE hInstance);
	void Render();

private:
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam); // ������ ���ν���
	void OnResize(); // â �������� �ݹ� �Լ�
	bool CreateAppResource(); // �� �ڿ� ����
	void DiscardAppResource(); // �� �ڿ� ���
	bool CreateDeviceResource(); // ��ġ �ڿ� ����
	void DiscardDeviceResource(); // ��ġ �ڿ� ���

private:
	// Ŭ������ �������� ����
	HWND hWnd = NULL;
	ID2D1Factory* pD2DFactory = NULL;
	ID2D1HwndRenderTarget* pRenderTarget = NULL;
	ID2D1SolidColorBrush* pBlackBrush = NULL;
	ID2D1SolidColorBrush* pLightSlateGrayBrush = NULL;
	ID2D1SolidColorBrush* pCornflowerBlueBrush = NULL;

	ID2D1RectangleGeometry* pRectangleGeometry = NULL;
	ID2D1RoundedRectangleGeometry* pRoundedRectangleGeometry = NULL;
	ID2D1EllipseGeometry* pEllipseGeometry = NULL;

	D2D1_POINT_2F p1 = {};
	D2D1_POINT_2F p2 = {};
	
	D2D1_RECT_F rect = {};
	D2D1_ROUNDED_RECT rrect = {};
	D2D1_ELLIPSE ellipse = {};
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MyApp myApp;
	if (!myApp.Initialize(hInstance)) return 1;

	// ���� ������ �޽��� ������ ������.
	MSG msg = {};
	while (msg.message != WM_QUIT)
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) != 0)
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			myApp.Render();
		}
	}
	return 0;
}

bool MyApp::Initialize(HINSTANCE hInstance)
{
	// ������ Ŭ������ �����.
	WNDCLASS wc = {};
	wc.lpfnWndProc = MyApp::WndProc;
	wc.cbWndExtra = sizeof(LONG_PTR);
	wc.hInstance = hInstance;
	wc.lpszClassName = L"MyApp";
	RegisterClass(&wc);

	// �����츦 ������.
	hWnd = CreateWindow(L"MyApp", L"MyApp", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 640, 480, NULL, NULL, hInstance, this);
	if (!hWnd) return false;

	ShowWindow(hWnd, SW_SHOWNORMAL);
	UpdateWindow(hWnd);

	// �� �ڿ��� ������.
	if (!CreateAppResource()) return false;
	return true;
}

LRESULT CALLBACK MyApp::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (uMsg == WM_CREATE)
	{
		CREATESTRUCT* pCreate = (CREATESTRUCT*)lParam;
		MyApp* pMyApp = (MyApp*)pCreate->lpCreateParams;
		SetWindowLongPtr(hWnd, GWLP_USERDATA, (LONG_PTR)pMyApp);
		return 0;
	}

	MyApp* pMyApp = (MyApp*)GetWindowLongPtr(hWnd, GWLP_USERDATA);
	if (!pMyApp)
	{
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}

	switch (uMsg)
	{
	case WM_SIZE:
	{
		pMyApp->OnResize();
		return 0;
	}
	case WM_DESTROY:
	{
		PostQuitMessage(0);
		return 0;
	}
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

// â �������� �ݹ� �Լ�
void MyApp::OnResize()
{
	if (!pRenderTarget) return;

	RECT rc;
	GetClientRect(hWnd, &rc);
	D2D1_SIZE_U size = D2D1::SizeU(rc.right - rc.left, rc.bottom - rc.top);
	// ����Ÿ���� ũ�⸦ �ٽ� ������.
	pRenderTarget->Resize(size);
}

bool MyApp::CreateAppResource()
{
	D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &pD2DFactory);

	// ��
	p1 = D2D1::Point2F(20.f, 200.f);
	p2 = D2D1::Point2F(600.f, 200.f);

	// �簢��
	rect = D2D1::RectF(20.f, 50.f, 160.f, 150.f);
	pD2DFactory->CreateRectangleGeometry(rect, &pRectangleGeometry);

	// �𼭸��� �ձ� �簢��
	rrect = D2D1::RoundedRect(D2D1::RectF(20.f, 50.f, 160.f, 150.f), 30.f, 20.f);
	pD2DFactory->CreateRoundedRectangleGeometry(rrect, &pRoundedRectangleGeometry);

	// Ÿ��
	ellipse = D2D1::Ellipse(D2D1::Point2F(90.f, 100.f), 70.f, 50.f);
	pD2DFactory->CreateEllipseGeometry(ellipse, &pEllipseGeometry);

	return true;
}


void MyApp::DiscardAppResource()
{
	SAFE_RELEASE(pD2DFactory);
}

bool MyApp::CreateDeviceResource()
{
	//��ȿ�ϴٸ� �� �Լ��� ������ �ʿ䰡 ����
	if (pRenderTarget) return true;

	RECT rc;
	GetClientRect(hWnd, &rc);
	D2D1_SIZE_U size = D2D1::SizeU(rc.right - rc.left, rc.bottom - rc.top);

	// D2D ����Ÿ���� ������.
	HRESULT hr = pD2DFactory->CreateHwndRenderTarget(D2D1::RenderTargetProperties(), D2D1::HwndRenderTargetProperties(hWnd, size), &pRenderTarget);
	if (FAILED(hr)) return false;

	// ������ �귯�ø� ������.
	hr = pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Black), &pBlackBrush);
	if (FAILED(hr)) return false;

	// ȸ�� �귯�ø� ������.
	hr = pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::LightSlateGray), &pLightSlateGrayBrush);
	if (FAILED(hr)) return false;

	// �Ķ��� �귯�ø� ������.
	hr = pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &pCornflowerBlueBrush);
	if (FAILED(hr)) return false;

	return true;
}

void MyApp::DiscardDeviceResource()
{
	SAFE_RELEASE(pRenderTarget);
	SAFE_RELEASE(pLightSlateGrayBrush);
	SAFE_RELEASE(pCornflowerBlueBrush);
}

// �׸� ������ �׸���.
void MyApp::Render()
{
	if (!CreateDeviceResource()) return;

	pRenderTarget->BeginDraw();
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
	pRenderTarget->Clear(D2D1::ColorF(D2D1::ColorF::White));

	// ����
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(0, 0));
	pRenderTarget->DrawLine(p1, p2, pBlackBrush, 5.f, 0);

	// �簢��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(0, 0));
	pRenderTarget->DrawRectangle(rect, pBlackBrush, 5.f, 0);

	// �𼭸��� �ձ� �簢��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(200, 0));
	pRenderTarget->DrawRoundedRectangle(rrect, pBlackBrush, 5.f, 0);

	// Ÿ��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(400, 0));
	pRenderTarget->DrawEllipse(ellipse, pBlackBrush, 5.f, 0);

	// �簢��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(0, 200));
	pRenderTarget->DrawGeometry(pRectangleGeometry, pBlackBrush, 5.f, 0);

	// �𼭸��� �ձ� �簢��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(200, 200));
	pRenderTarget->DrawGeometry(pRoundedRectangleGeometry, pBlackBrush, 5.f, 0);

	// Ÿ��
	pRenderTarget->SetTransform(D2D1::Matrix3x2F::Translation(400, 200));
	pRenderTarget->DrawGeometry(pEllipseGeometry, pBlackBrush, 5.f, 0);

	HRESULT hr = pRenderTarget->EndDraw();
	if (FAILED(hr) || hr == D2DERR_RECREATE_TARGET) DiscardDeviceResource();

}